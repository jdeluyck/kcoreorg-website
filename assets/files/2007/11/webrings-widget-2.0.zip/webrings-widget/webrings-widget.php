<?php
/*
Plugin Name: Webrings Widget
Plugin URI: http://www.kcore.org/?menumain=3&menusub=7
Description: Widget for your webrings. Edit your webrings <a href="templates.php?file=wp-content%2Fplugins%2Fwebrings-widget%2Fwebrings.txt&submit=Edit+file+%C2%BB">here</a>.  (Works for me, maybe not for you!)
Version: 2.0
Author: Jan De Luyck
Author URI: http://www.kcore.org
*/
/*
webrings - shows webrings links with prev/list/next/random links.

Copyright (C) 2006 - 2007 Jan De Luyck  <jan -at- kcore -dot- org>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

The full text of the license can be found here:
http://www.gnu.org/licenses/gpl.txt

*/

define ("_widget_title", "Webrings");
define ("_separator", "|");

function show_webrings($args)
{	
	global $wp_locale;
	extract($args);
	
	$webringDataFile = dirname(__FILE__) . '/webrings.txt';

	/* get options */
	$options  = get_option("Webrings");
	if (empty($options['title']))
		$options['title'] = _widget_title;
	
	/* start our widget */
	echo $before_widget;
		
	/* print the title */
	echo $before_title . $options['title'] . $after_title;
	
	if (! file_exists($webringDataFile))
		echo "No webrings data file found.";
	else
	{
		$data = file($webringDataFile);

		echo "<ul>";
		
		foreach ($data as $webring)
		{
			if (trim($webring) == '' || $webring[0] == "#") continue;

			$temp = explode(_separator, $webring);

			$name       = strip_tags(trim($temp[0]));
			$image      = strip_tags(trim($temp[1]));
			$url        = strip_tags(trim($temp[2]));
			$prev_url   = strip_tags(trim($temp[3]));
			$list_url   = strip_tags(trim($temp[4]));
			$next_url   = strip_tags(trim($temp[5]));
			$random_url = strip_tags(trim($temp[6]));

			echo '<li><strong><a href="' . $url . '" target="_blank">';

			if ($image == "%")
				echo $name;
			else
				echo '<img src="' . $image . ' border="0" alt="'. $name . '">';

			echo '</a></strong>';

			echo '<br>';

			echo '<a href="' . $prev_url   . '" target="_blank">Previous</a> ' . _separator . ' ';
			echo '<a href="' . $list_url   . '" target="_blank">List</a> ' . _separator . ' ';
			echo '<a href="' . $next_url   . '" target="_blank">Next</a> ' . _separator . ' ';
			echo '<a href="' . $random_url . '" target="_blank">Random</a>';

			echo '</li>';
		}
		echo "</ul>";
	}
	
	/* end our widget */
	echo $after_widget;
}

/* Register our widget with the widget system and add a callback to print our stuff */
function webrings_widget_register () 
{
	if (!function_exists('register_sidebar_widget'))
		return;

	/* register the plugin with the sidebar and the control stuff */		
	register_sidebar_widget("Webrings", 'show_webrings');	
	register_widget_control("Webrings", 'webrings_widget_control', 300, 100);
}

function webrings_widget_control()
{
	$options = $newoptions = get_option("Webrings");
	if ($_POST["webrings-submit"])
		$newoptions['title'] = strip_tags(stripslashes($_POST["webrings-title"]));

	if ($options != $newoptions) 
	{
		$options = $newoptions;
		update_option("Webrings", $options);
	}

	$title = attribute_escape($options['title']);
	?>
			<p><label for="webrings-title"><?php _e('Title:'); ?> <input style="width: 250px;" id="webrings-title" name="webrings-title" type="text" value="<?php echo $title; ?>" /></label></p>
			<input type="hidden" id="webrings-submit" name="webrings-submit" value="1" />
	<?php
}

/* Delay plugin execution until sidebar is loaded */
add_action('widgets_init', 'webrings_widget_register');
?>
