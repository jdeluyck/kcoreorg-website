How to use the webrings widget
==============================
1. Upload the webrings-widget directory in your WordPress plugins directory (usually wp-content/plugins).

2. In the WordPress administrator console, go to the Plugins tab, and activate the 'Webrings Widget' plugin.

3. Put the widget in your sidebar: go to Presentation -> Widgets and drag 'Webrings' into your sidebar. You can configure the widget by clicking on the small icon on the right in the Webrings box (once it is in the sidebar).

That's it! Enjoy!

Adding new webrings to the webrings.txt file
=============================================
The formatting for the webrings in the webrings.txt file is pretty self-explanatory:

Name|Image|URL|PrevURL|ListURL|NextURL|RandomURL

eg:

RingName|%|http://ringpage|http://ringpage?prev|http://ringpage?list|http://ringpage?next|http://ringpage?random

Author
======
This widget was created by Jan De Luyck (jan -at- kcore -dot- org).
You can find more Wordpress plugins / widgets at 
http://www.kcore.org/?menumain=3&menusub=7