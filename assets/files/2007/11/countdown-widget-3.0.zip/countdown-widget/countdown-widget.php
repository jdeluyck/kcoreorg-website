<?php
/*
Plugin Name: Countdown Widget
Plugin URI: http://www.kcore.org/?menumain=3&menusub=7
Description: Counts down in days, hours, minutes and seconds to a specified date.  Edit your dates <a href="templates.php?file=wp-content%2Fplugins%2Fcountdown-widget%2Fdates.txt&submit=Edit+file+%C2%BB">here</a>.  (Works for me, maybe not for you!)
Version: 3.0
Author: Jan De Luyck
Author URI: http://www.kcore.org
*/
/*
Countdown - Counts down in days, hours, minutes and seconds to a specified date.

Copyright (C) 2006 - 2007 Jan De Luyck  <jan -at- kcore -dot- org>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

The full text of the license can be found here:
http://www.gnu.org/licenses/gpl.txt

*/

define ("_widget_title", "Countdown");
define ("_widget_eventstoshow", 0);
define ("_widget_showpast", false);

function show_countdown($args)
{
	global $wp_locale;
	extract($args);
	
	$dateFile = dirname(__FILE__) . '/dates.txt';
	
	/* get options */
	$options  = get_option("Countdown");
	if (empty($options['title'])) 
		$options['title'] = _widget_title;
	if (empty($options['showpast']))
		$options['showpast'] = _widget_showpast;
	if (empty($options['eventstoshow']))
		$options['eventstoshow'] = _widget_eventstoshow;
			
	/* start our widget */
	echo $before_widget;
		
	/* print the title */
	echo $before_title . $options['title'] . $after_title;
	
	if (! file_exists($dateFile))
		echo "No countdown data file found.";
	else
	{
			
		$data = implode('', file($dateFile));
		$dates = explode("\n", $data);
		$finalEntries = array();
	
		foreach($dates as $entry)
		{
			if (trim($entry) == '' || $entry[0] == "#") continue;

			$temp = explode(" ", $entry);
			$eventUnixTimeStamp = strtotime(array_shift($temp) . " " . array_shift($temp));
			$eventText = implode(" ", $temp);
			
			$finalEntries[(string)$eventUnixTimeStamp] = $eventText;
		}

		ksort($finalEntries);

		/* if there is a limit on the amount of entries, drop them until we keep the necessary amount so
		   only the last ones are shown */
		if ($options['eventstoshow'] != 0)
		{
			reset($finalEntries);
			for ($i = count($finalEntries); $i > $options['eventstoshow']; $i--)
				next($finalEntries);
				
			do
			{
				$limitedEntries[key($finalEntries)] = current($finalEntries);
			}
			while (next($finalEntries) !== false);
			
			$finalEntries = $limitedEntries;
		}
		
		echo "<ul>";
		
		foreach($finalEntries as $eventTime => $eventText)
			countdown_days($eventText, $eventTime, $options);

		echo "</ul>";
	}
}

function countdown_days($event, $date, $options)
{
	$now = mktime(date("H"), date("i"), date("s") - date("Z") + (get_settings('gmt_offset') * 3600), date("m"), date("d"), date("Y"));
	  
	$until = $date - $now;

	$daysLeft  = intval($until / (60*60*24)*1);
	$hoursLeft = intval(($until % (60*60*24))/(60*60)*1);
	$minsLeft  = intval((($until % (60*60*24))%(60*60))/(60)*1);
	$secsLeft  = intval(((($until % (60*60*24))%(60*60))%(60))*1);

	if ($secsLeft >= 0) 
	{
		echo "<li>";
		echo "<span style='color: #F5F5F5;'>" . $daysLeft . " days, " . $hoursLeft . " hours, " . $minsLeft . " minutes, and " . $secsLeft . " seconds left until " . $event . "</span>";
		echo "</li>";
	}
	else
	{
		if ($options['showpast'])
		{
			$daysPast = intval(abs($until) / (60*60*24)*1);
 			echo "<li>";
			echo date("M. j Y", $date) . " - " . $event . " (". $daysPast . " day" . ($daysPast == 1?"":"s") . " ago)";
			echo "</li>";
		}
	}
}

/* Register our widget with the widget system and add a callback to print our stuff */
function countdown_widget_register () 
{
	if (!function_exists('register_sidebar_widget'))
		return;

	/* register the plugin with the sidebar and the control stuff */		
	register_sidebar_widget("Countdown", 'show_countdown');	
	register_widget_control("Countdown", 'countdown_widget_control', 300, 150);
}

function countdown_widget_control()
{
	$options = $newoptions = get_option("Countdown");
	if ($_POST["countdown-submit"])
	{
		$newoptions['title'] = strip_tags(stripslashes($_POST["countdown-title"]));
		$newoptions['eventstoshow'] = strip_tags(stripslashes($_POST["countdown-eventstoshow"]));
		$newoptions['showpast'] = isset($_POST['countdown-showpast']);
		
		if (! is_numeric($newoptions['eventstoshow']))
			$newoptions['eventstoshow'] = "";
	}
	
	if ($options != $newoptions) 
	{
		$options = $newoptions;
		update_option("Countdown", $options);
	}

	$eventstoshow = attribute_escape($options['eventstoshow']);
	$title = attribute_escape($options['title']);
	$showpast = $options['showpast'] ? 'checked="checked"' : '';
	
	?>
			<p><label for="countdown-title"><?php _e('Title:'); ?> <input style="width: 250px;" id="countdown-title" name="countdown-title" type="text" value="<?php echo $title; ?>" /></label></p>
			<p style="text-align:left;margin-right:40px;"><label for="countdown-eventstoshow"><?php _e('Events to show (0 = show all): '); ?> <input style="width: 250px;" id="countdown-eventstoshow" name="countdown-eventstoshow" type="text" value="<?php echo $eventstoshow; ?>" /></label></p>
			<p style="text-align:left;margin-right:40px;"><label for="countdown-showpast"><?php _e('Show past events: '); ?> <input class="checkbox" type="checkbox" id="countdown-showpast" name="countdown-showpast" <?php echo $showpast; ?> /></label></p>
			<input type="hidden" id="countdown-submit" name="countdown-submit" value="1" />
	<?php
}

/* Delay plugin execution until sidebar is loaded */
add_action('widgets_init', 'countdown_widget_register');

?>