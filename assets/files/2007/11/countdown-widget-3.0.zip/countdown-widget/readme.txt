How to use the countdown widget
===============================
1. Upload the countdown-widget directory in your WordPress plugins directory (usually wp-content/plugins).

2. In the WordPress administrator console, go to the Plugins tab, and activate the 'Countdown Widget' plugin.

3. Put the widget in your sidebar: go to Presentation -> Widgets and drag 'Countdown' into your sidebar. You can configure the widget by clicking on the small icon on the right in the Countdown box (once it is in the sidebar).

That's it! Enjoy!

Adding new events to the dates.txt file
=======================================
The formatting for the dates in the dates.txt file is pretty self-explanatory:

YYYY-MM-DD HH:MM:SS Entry text

eg:

2007-11-22 10:14:00 This is a test entry!

Author
======
This widget was created by Jan De Luyck (jan -at- kcore -dot- org).
You can find more Wordpress plugins / widgets at 
http://www.kcore.org/?menumain=3&menusub=7