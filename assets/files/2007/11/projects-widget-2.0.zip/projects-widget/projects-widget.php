<?php
/*
Plugin Name: Projects Widget
Plugin URI: http://www.kcore.org/?menumain=3&menusub=7
Description: Prints the name of the project and a bar graph. Edit your projects <a href="templates.php?file=wp-content%2Fplugins%2Fprojects-widget%2Fprojects.txt&submit=Edit+file+%C2%BB">here</a>.  (Works for me, maybe not for you!)
Version: 2.0
Author: Jan De Luyck
Author URI: http://www.kcore.org
*/
/*
Projects - shows project status with a nice bargraph

Copyright (C) 2006 - 2007 Jan De Luyck  <jan -at- kcore -dot- org>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

The full text of the license can be found here:
http://www.gnu.org/licenses/gpl.txt

*/

define ("_widget_title", "Projects");
define ("_widget_imagepath", $_SERVER["REQUEST_URI"] . "wp-content/plugins/projects-widget/images/");
define ("_widget_colour", "blue");
define ("_separator", "|");


function show_projects($args) 
{
	global $wp_locale;
	extract($args);
	
	$projectsDataFile = dirname(__FILE__) . '/projects.txt';

	/* get options */
	$options  = get_option("Projects");
	if (empty($options['title']))
		$options['title'] = _widget_title;

	if (empty($options['imagepath']))
		$options['imagepath'] = _widget_imagepath;
		
	if (empty($options['colour']))
		$options['colour'] = _widget_colour;
	
	/* start our widget */
	echo $before_widget;
		
	/* print the title */
	echo $before_title . $options['title'] . $after_title;
	
	if (! file_exists($projectsDataFile))
		echo "No webrings data file found.";
	else
	{
		$data = file($projectsDataFile);

		echo "<ul>";
		foreach ($data as $aProject)
		{
			if (trim($aProject) == '' || $aProject[0] == "#") continue;
			
			$project = explode(_separator, $aProject);
						
			$percentage = str_replace("%", "", trim($project[1]));

			printProjectName(trim($project[0]), $percentage);
			printProjectBar($percentage, $options);
		}
		echo "</ul>";
	}
}

function printProjectName($name, $percentage)
{
	if ($percentage > 0 && $percentage <= 100)
		echo "<div class='projects-widget'>" . $name . " (" . trim($percentage) . "%)</div>\n";
	else
		print "<div class=\"projects-widget\">" . $name . "</div>\n";
}

function printProjectBar($percentage, $options)
{
	$clearStart = $options['imagepath'] . "/clear_start.png";
	$coloredStart = $options['imagepath'] . "/" . $options["colour"] . "_colored_start.png";
	
	$clearEnd = $options['imagepath'] . "/clear_end.png";
	$coloredEnd = $options['imagepath'] . "/" . $options["colour"] . "_colored_end.png";
	
	$clearMid = $options['imagepath'] . "/clear.png";
	$coloredMid = $options['imagepath'] . "/" . $options["colour"] . "_colored.png";
		
	$clearAmount = 100 - $percentage;
	
	if ($percentage > 0 && $percentage < 100)
	{
		echo "<img src='$coloredStart' />";
		echo "<img src='$coloredMid' width='$percentage' height='16' />";
		echo "<img src='$clearMid' width='$clearAmount' height='16' />";
		echo "<img src='$clearEnd' />";
	}
	elseif ($percentage == 100)
	{
		echo "<img src='$coloredStart' />";
		echo "<img src='$coloredMid' width='100' height='16' />";
		echo "<img src='$coloredEnd' />";
	}
	else
	{
		echo "<img src='$clearStart' />";
		echo "<img src='$clearMid' width='100' height='16' />";
		echo "<img src='$clearEnd' />";
	}
	
	echo "\n";
}

/* Register our widget with the widget system and add a callback to print our stuff */
function projects_widget_register () 
{
	if (!function_exists('register_sidebar_widget'))
		return;

	/* register the plugin with the sidebar and the control stuff */		
	register_sidebar_widget("Projects", 'show_projects');	
	register_widget_control("Projects", 'projects_widget_control', 300, 150);
}

function projects_widget_control()
{
	$colours = array("blue","orange","pink","purple");
	
	$options = $newoptions = get_option("Projects");
	if ($_POST["projects-submit"])
	{
		$newoptions['title'] = strip_tags(stripslashes($_POST["projects-title"]));
		$newoptions['imagepath'] = strip_tags(stripslashes($_POST["projects-imagepath"]));
		$newoptions['colour'] = strip_tags(stripslashes($_POST["projects-colour"]));
	}
	
	if ($options != $newoptions) 
	{
		$options = $newoptions;
		update_option("Projects", $options);
	}

	$imagepath = attribute_escape($options['imagepath']);
	$title = attribute_escape($options['title']);
	$colour = attribute_escape($options['colour']);
	
	?>
			<p><label for="projects-title"><?php _e('Title:'); ?> <input style="width: 250px;" id="projects-title" name="projects-title" type="text" value="<?php echo $title; ?>" /></label></p>
			<p style="text-align:left;margin-right:40px;"><label for="projects-imagepath"><?php _e('Image path URL: '); ?> <input style="width: 250px;" id="projects-imagepath" name="projects-imagepath" type="text" value="<?php echo $imagepath; ?>" /></label></p>
			<p style="text-align:left;margin-right:40px;"><label for="projects-colour"><?php _e('Bar colour: '); ?> <select style="width: 250px;" id="projects-colour" name="projects-colour"><?php
			 	foreach ($colours as $aColour)
					echo "<option value='$aColour'" . ($colour == $aColour?" selected":"") . ">$aColour</option>";
				?></select></label></p>
			<input type="hidden" id="projects-submit" name="projects-submit" value="1" />
	<?php
}

/* Delay plugin execution until sidebar is loaded */
add_action('widgets_init', 'projects_widget_register');
?>
