How to use the projects widget
==============================
1. Upload the projects-widget directory in your WordPress plugins directory (usually wp-content/plugins).

2. In the WordPress administrator console, go to the Plugins tab, and activate the 'Projects Widget' plugin.

3. Put the widget in your sidebar: go to Presentation -> Widgets and drag 'Projects' into your sidebar. You can configure the widget by clicking on the small icon on the right in the Projects box (once it is in the sidebar).

That's it! Enjoy!

Adding new projects to the projects.txt file
=============================================
The formatting for the projects in the projects.txt file is pretty self-explanatory:

Project Name|Percentage

eg:

Test Project|50%

Author
======
This widget was created by Jan De Luyck (jan -at- kcore -dot- org).
You can find more Wordpress plugins / widgets at 
http://www.kcore.org/?menumain=3&menusub=7