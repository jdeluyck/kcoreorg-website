#!/usr/bin/php4 -q
<?php
/*
This script converts sphpblog content to WordPress content.
Use at own risk.

sphpblog2wp conversion script - copyright (c) 2005 Jan De Luyck

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

The full text of the license can be found here:
http://www.gnu.org/licenses/gpl.txt

*/


/* SETTINGS */
$dir = "/tmp/05/09";			// point this to a month folder!

$db_host = "localhost";
$db_name = "wp-test";
$db_user = "root";
$db_pass = "";


/* SCRIPT */
/* dont change anything below here. Well, you can, but if it breaks
   you get to keep all the pieces! */

// connect to the allmighty database
// we assume mysql. mysql is allmighty.
echo "Connecting to MySQL...\n";

if (($db = mysql_connect($db_host, $db_user, $db_pass)) === false)
{
	echo "ERROR: could not connect to mysql!\n";
	exit -1;
}

if (! mysql_select_db($db_name))
{
	echo "ERROR: could not connect to the $db_name database!\n";
	exit -1;
}

echo "Starting run for $dir...\n";

if (is_dir($dir))
{
	if ($dh = opendir($dir))
	{
		while (($file = readdir($dh)) !== false)
		{
			unset ($temp);
			unset ($temp2);
			unset ($postdata);

			$post = $dir . '/' . $file;
			if (is_dir($post))
				continue;

			$commentdir = $dir . '/' . substr($file,0,-4) . '/comments';

			$postdata = file_get_contents($post);

			$temp = explode("|", $postdata);
			$temp2["subject"] = mysql_escape_string($temp[3]);
			$temp2["body"] = mysql_escape_string($temp[5]);
			$temp2["date"] =	$temp[9];

			$sql = "insert into wp_posts values(
					'',
					0,
					'" . date("Y-m-d H:i:s", $temp2["date"]) . "',
					'" . date("Y-m-d H:i:s", $temp2["date"] - (2*3600)) . "' ,
					'" . $temp2["body"] . "',
					'" . $temp2["subject"] . "',
					0,
					'',
					'publish',
					'open',
					'open',
					'',
					'" . substr($post["subject"],0,200) . "',
					'',
					'',
					'',
					'',
					'',
					0,
					'',
					0)";

			mysql_query($sql);

			$res = mysql_query("select max(id) from wp_posts;");
			$postID = mysql_result($res,0);

			echo "Post: $post, inserted as ID $postID\n";

			if (file_exists($commentdir) && is_dir($commentdir))
			{
				$pdh = opendir($commentdir);

				while (($commentfile = readdir($pdh)) !== false)
				{
					if (is_dir($commentdir . '/' . $commentfile))
						continue;

					$comment = file_get_contents($commentdir . '/' . $commentfile);
					$temp = explode("|", $comment);

					$temp2["author"] = mysql_escape_string($temp[3]);
					$temp2["date"] = $temp[5];
					$temp2["body"] = mysql_escape_string($temp[7]);
					$temp2["email"] = mysql_escape_string($temp[9]);

					$sql="iNSERT INTO wp_comments VALUES (
					'',
					" . $postID . ",
					'" . $temp2["author"] . "',
					'" . $temp2["email"] . "',
					'',
					'',
					'" . date("Y-m-d H:i:s", $temp2["date"]) . "',
					'" . date("Y-m-d H:i:s", $temp2["date"] - (2*3600)) . "' ,
					'" . $temp2["body"] . "',
					0,
					'1',
					'sphpblog2wp',
					'',
					0,
					0)";

					mysql_query($sql);

					$res = mysql_query("select max(comment_id) from wp_comments;");
					$commentID = mysql_result($res,0);


					echo "-- Comment: $commentdir/$commentfile, inserted as ID $commentID\n";
				}

				closedir($pdh);

       		}
       	}

		closedir($dh);

		echo "Done!\n";
   }
}

mysql_close($db);

?>