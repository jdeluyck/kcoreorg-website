<?php
/*
Plugin Name: Countdown
Plugin URI: http://www.wordpress.org/#
Description: Counts down in days, hours, minutes and seconds to a specified date.  Edit your dates <a href="templates.php?file=wp-content%2Fplugins%2Fdates.txt&submit=Edit+file+%C2%BB">here</a>.  (Works for me, maybe not for you!)
Version: 2.0
Author: Jan De Luyck
Author URI: http://www.kcore.org
*/
/*
Countdown - Counts down in days, hours, minutes and seconds to a specified date.

Based on the plugin found at http://www.asymptomatic.net/wp-hacks

This code is licensed under the MIT License.
http://www.opensource.org/licenses/mit-license.php
Copyright (c) 2004 Owen Winkler

Permission is hereby granted, free of charge, to any person
obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software,
and to permit persons to whom the Software is furnished to
do so, subject to the following conditions:

The above copyright notice and this permission notice shall
be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/


function dates_to_remember($showonly = -1, $timefrom = null, $startswith = '<li>', $endswith = '</li>', $paststartswith = '<li class="pastevent" style="display:none;">', $pastendswith = '</li>')
{
	$datefile = implode('', file(dirname(__FILE__) . '/dates.txt'));
	$dates = explode("\n", $datefile);
	$dtr = array();
	
	foreach($dates as $entry)
	{
		if(trim($entry) == '') continue;
		$temp = explode(" ", $entry);
		$matches[0] = array_shift($temp);
		$matches[1] = array_shift($temp);
		$matches[2] = strtotime($matches[0] . " " . $matches[1]);
		$matches[3] = implode(" ", $temp);

		$dtr[$matches[2]] = $matches[3];
	}

	ksort($dtr);

	foreach($dtr as $eventtime => $event)
	{
		countdown_days($event, $eventtime, $startswith, $endswith, $paststartswith, $pastendswith);
		$showonly --;
		if($showonly == 0) break;
	}
}

function countdown_days($event, $date, $startswith = '', $endswith = '', $paststartswith = '', $pastendswith = '', $do_daystil = true) {
	  $now = mktime(date("H"), date("i"), date("s") - date("Z") + (get_settings('gmt_offset') * 3600), date("m"), date("d"), date("Y"));
	  
	  $until = $date - $now;

      $daysLeft = intval($until / (60*60*24)*1);
      $hoursLeft = intval(($until % (60*60*24))/(60*60)*1);
      $minsLeft = intval((($until % (60*60*24))%(60*60))/(60)*1);
      $secsLeft = intval(((($until % (60*60*24))%(60*60))%(60))*1);

	  if($secsLeft >= 0) {
 		echo $startswith;
        echo $daysLeft . " days, " . $hoursLeft . " hours, " . $minsLeft . " minutes, and " . $secsLeft . " seconds left until " . $event;
		echo $endswith;
	}
	else
	{
 		echo $paststartswith;
		$date_format = 'M. j';
		echo date($date_format, strtotime($date));
		echo " - {$event}";
		if($do_daystil)
		{
			echo " (";
			switch(abs($until))
			{
			case 1: echo '1 day ago'; break;
			default: echo "{$until} days ago"; break;
			}
			echo ")";
		}
		echo $pastendswith;
	}
}

?>