HOW TO USE COUNTDOWN
====================

Put both the countdown.php and dates.txt files in your WordPress plugins directory (usually wp-content/plugins).

In the WordPress admin console, go to the Plugins tab, and activate the Countdown plugin.

Put this code into your sidebar menu:

<li id="importantdates">Dates to Remember:
    <ul>
    <?php
    dates_to_remember(5);
    ?>
    </ul>
</li>

The "5" tells it how many dates to display.  Omit this number to display all events for a year.


ADDING NEW EVENTS
-----------------
The formatting for the dates in the dates.txt file is pretty self-explanatory:

YYYY-MM-DD HH:MM:SS Entry text
