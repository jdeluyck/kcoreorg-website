NOTE:
This plugin is meant for webrings that have the typical 4-link style: next, prev, random and list.

HOW TO USE WEBRINGS
===================

Put both the webrings.php and the webrings.txt files in your WordPress plugins directory (usually wp-content/plugins).

In the WordPress admin console, go to the Plugins tab, and activate the Webrings plugin.

Put this code into your sidebar menu:

<li><h2>Webrings</h2>
		<ul>
		<?php show_webrings(); ?>
		</ul>
</li>


ADDING NEW WEBRINGS
-------------------
The formatting is pretty self-explanatory

YYYY-MM-DD HH:MM:SS Entry text
