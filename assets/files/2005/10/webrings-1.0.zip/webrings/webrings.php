<?php
/*
Plugin Name: Webrings
Plugin URI: http://www.kcore.org/?menumain=3&menusub=7
Description: Creates entries for webrings. Edit your webrings <a href="templates.php?file=wp-content%2Fplugins%2Fwebrings.txt&submit=Edit+file+%C2%BB">here</a>.  (Works for me, maybe not for you!)
Version: 1.0
Author: Jan De Luyck
Author URI: http://www.kcore.org
*/
/*
webrings - shows webrings links with prev/list/next/random links.

Copyright (C) 2006 Jan De Luyck  <jan -at- kcore -dot- org>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

The full text of the license can be found here:
http://www.gnu.org/licenses/gpl.txt

*/


function show_webrings($startswith='', $endswith='', $seperator='|')
{
	$ringfile = dirname(__FILE__) . '/webrings.txt';

	$data = file($ringfile);

	foreach ($data as $webring)
	{
		if (trim($webring) == '' || $webring[0] == "#") continue;

		$temp = explode("|", $webring);

		$name       = trim($temp[0]);
		$image      = trim($temp[1]);
		$url        = trim($temp[2]);
		$prev_url   = trim($temp[3]);
		$list_url   = trim($temp[4]);
		$next_url   = trim($temp[5]);
		$random_url = trim($temp[6]);

		echo $startswith;
		echo '<strong><a href="' . $url . '" target="_blank">';

		if ($image == "%")
			echo $name;
		else
			echo '<img src="' . $image . ' border="0">';

		echo '</a></strong>';

		echo '<br>';

		echo '<a href="' . $prev_url   . '" target="_blank">Previous</a> ' . $seperator . ' ';
		echo '<a href="' . $list_url   . '" target="_blank">List</a> ' . $seperator . ' ';
		echo '<a href="' . $next_url   . '" target="_blank">Next</a> ' . $seperator . ' ';
		echo '<a href="' . $random_url . '" target="_blank">Random</a>';

		echo '<br>';

		echo $endswith;
	}
}
?>
